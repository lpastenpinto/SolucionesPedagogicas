<?php 
// La función no será utilizada antes del 'init'.
add_action( 'init', 'my_custom_init' );
/* Here's how to create your customized labels */
function my_custom_init() {
	$labels = array(
	    'name' => _x( 'Libros', 'post type general name' ),
        'singular_name' => _x( 'Libro', 'post type singular name' ),
        'add_new' => _x( 'Añadir nuevo', 'book' ),
        'add_new_item' => __( 'Añadir nuevo Libro' ),
        'edit_item' => __( 'Editar Libro' ),
        'new_item' => __( 'Nuevo Libro' ),
        'view_item' => __( 'Ver Libro' ),
        'search_items' => __( 'Buscar Libros' ),
        'not_found' =>  __( 'No se han encontrado Libros' ),
        'not_found_in_trash' => __( 'No se han encontrado Libros en la papelera' ),
        'parent_item_colon' => ''
    );
 
    // Creamos un array para $args
    $args = array( 'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
    );
 
    register_post_type( 'libro', $args ); /* Registramos y a funcionar */
}
// Lo enganchamos en la acción init y llamamos a la función create_book_taxonomies() cuando arranque
add_action( 'init', 'create_book_taxonomies', 0 );
 
// Creamos dos taxonomías, género y autor para el custom post type "libro"
function create_book_taxonomies() {
	// Añadimos nueva taxonomía y la hacemos jerárquica (como las categorías por defecto)
	$labels = array(
	'name' => _x( 'Géneros', 'taxonomy general name' ),
	'singular_name' => _x( 'Género', 'taxonomy singular name' ),
	'search_items' =>  __( 'Buscar por Género' ),
	'all_items' => __( 'Todos los Géneros' ),
	'parent_item' => __( 'Género padre' ),
	'parent_item_colon' => __( 'Género padre:' ),
	'edit_item' => __( 'Editar Género' ),
	'update_item' => __( 'Actualizar Género' ),
	'add_new_item' => __( 'Añadir nuevo Género' ),
	'new_item_name' => __( 'Nombre del nuevo Género' ),
);
register_taxonomy( 'genero', array( 'libro' ), array(
	'hierarchical' => true,
	'labels' => $labels, /* ADVERTENCIA: Aquí es donde se utiliza la variable $labels */
	'show_ui' => true,
	'query_var' => true,
	'rewrite' => array( 'slug' => 'genero' ),
));
// Añado otra taxonomía, esta vez no es jerárquica, como las etiquetas.
$labels = array(
	'name' => _x( 'Escritores', 'taxonomy general name' ),
	'singular_name' => _x( 'Escritor', 'taxonomy singular name' ),
	'search_items' =>  __( 'Buscar Escritores' ),
	'popular_items' => __( 'Escritores populares' ),
	'all_items' => __( 'Todos los escritores' ),
	'parent_item' => null,
	'parent_item_colon' => null,
	'edit_item' => __( 'Editar Escritor' ),
	'update_item' => __( 'Actualizar Escritor' ),
	'add_new_item' => __( 'Añadir nuevo Escritor' ),
	'new_item_name' => __( 'Nombre del nuevo Escritor' ),
	'separate_items_with_commas' => __( 'Separar Escritores por comas' ),
	'add_or_remove_items' => __( 'Añadir o eliminar Escritores' ),
	'choose_from_most_used' => __( 'Escoger entre los Escritores más utilizados' )
);
 
register_taxonomy( 'escritor', 'libro', array(
	'hierarchical' => false,
	'labels' => $labels, /* ADVERTENCIA: Aquí es donde se utiliza la variable $labels */
	'show_ui' => true,
	'query_var' => true,
	'rewrite' => array( 'slug' => 'escritor' ),
));
} // Fin de la función create_book_taxonomies().
// Nuestra función de tipo de mensaje personalizado
function create_posttype() {

	register_post_type( 'Peliculas',
	// Opciones de Custom Post Type 
		                array(
			'labels' => array(
			'name' => __( 'Peliculas' ),
			'singular_name' => __( 'Pelicula' )
			            ),
			'public' => true,
			'has_archive' => true,
			'rewrite' => array('slug' => 'Peliculas'),
		)
	);
}
// Conexión de nuestra función para configurar el tema
add_action( 'init', 'create_posttype' );

/*
* Creación de una función para crear nuestra Custom Post Type
*/

function custom_post_type() {

// Setear UI labels for Custom Post Type
	$labels = array(
		'name'                => _x( 'Peliculas', 'Post Type General Name', 'twentytwelve' ),
		'singular_name'       => _x( 'Pelicula', 'Post Type Singular Name', 'twentytwelve' ),
		'menu_name'           => __( 'Peliculas', 'twentytwelve' ),
		'parent_item_colon'   => __( 'Parent Pelicula', 'twentytwelve' ),
		'all_items'           => __( 'All Peliculas', 'twentytwelve' ),
		'view_item'           => __( 'View Pelicula', 'twentytwelve' ),
		'add_new_item'        => __( 'Add New Pelicula', 'twentytwelve' ),
		'add_new'             => __( 'Add New', 'twentytwelve' ),
		'edit_item'           => __( 'Edit Pelicula', 'twentytwelve' ),
		'update_item'         => __( 'Update Pelicula', 'twentytwelve' ),
		'search_items'        => __( 'Search Pelicula', 'twentytwelve' ),
		'not_found'           => __( 'Not Found', 'twentytwelve' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwelve' ),
	);
	
// guardar otras opciones para Custom Post Type
	
	$args = array(
		'label'               => __( 'Peliculas', 'twentytwelve' ),
		'description'         => __( 'Pelicula noticias y comentarios', 'twentytwelve' ),
		'labels'              => $labels,
		// Características del  CPT que apoya en el Editor del anuncio
		'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
		// Puede asociar este CPT con una taxonomía o taxonomía personalizada.
		'taxonomies'          => array( 'genres' ),
		/* A CPT jerárquica es como páginas y puede tener
        * Padres y elementos secundarios. A CPT no jerárquica
        * Es como Mensajes.
		*/	
		'hierarchical'        => true,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	
	// Registrando tu Custom Post Type
	register_post_type( 'Peliculas', $args );

}

/*Enganche en la acción init 
**para que la función que contiene el registro de tipo de mensaje no se ejecuta de forma innecesaria
*/

add_action( 'init', 'custom_post_type', 0 );

function personalizar_login() {
    echo '<style type="text/css">
          h1 a { background-image:url('.get_bloginfo('template_directory').'/images/petals.jpg) !important; }
    </style>';
}
add_action('login_head', 'personalizar_login');

add_action( 'pre_get_posts', 'add_my_post_types_to_query' );

function add_my_post_types_to_query( $query ) {
	if ( is_home() && $query->is_main_query() )
		$query->set( 'post_type', array( 'post', 'Peliculas' ) );
	return $query;
}

//creando un widget

function example_dashboard_widget_function() {
	// Aquí mostramos lo que queramos o necesitemos
	echo "Bienvenido al panel de control del blog";
} 

// Crea la función usando la accion de un "hook" o gancho
function example_add_dashboard_widgets() {
	wp_add_dashboard_widget('example_dashboard_widget', 'Ejemplo de Widget en Escritorio', 'example_dashboard_widget_function');
}
add_action('wp_dashboard_setup', 'example_add_dashboard_widgets' );

//funcion para agregar una hoja de estylos
function custom_login_css() {
echo '<link rel="stylesheet" type="text/css" href="'.get_stylesheet_directory_uri().'../login/login-styles.css" />';
}
add_action('login_head', 'custom_login_css');

//login en la pagina
 function mqw_login_form($atts, $content = null) {
  extract(shortcode_atts(array(
   "redirectto"=> $_SERVER['REQUEST_URI']
    ), $atts));   
    if (!(current_user_can('level_0'))){ 
    	$output= '<h2>Login</h2>'; 
    	$output.= '<form action="'.get_option('home').'/wp-login.php" method="post">';
        $output.= '<input type="text" name="log" id="log" value="'.wp_specialchars(stripslashes($user_login), 1) .'" size="20" />'; 
        $output.= '<input type="password" name="pwd" id="pwd" size="20" />'; 
        $output.= '<input type="submit" name="submit" value="Enviar" class="button" />'; 
        $output.= ' <p>'; 
        $output.= ' <label for="rememberme"><input name="rememberme" id="rememberme" type="checkbox" checked="checked" value="forever" /> Recordarme</label>'; 
        $output.= ' <input type="hidden" name="redirect_to" value="'.$redirectto.'" />'; 
        $output.= ' </p>'; 
        $output.= '</form>'; 
        $output.= '<a href="'.get_option('home').'/wp-login.php?action=lostpassword">Recuperar Password</a>'; 
    } else { 
    	$output.= '<h2>Logout</h2>'; 
    	$output.= '<a href="'.wp_logout_url(urlencode($_SERVER['REQUEST_URI'])).'">logout</a><br />'; 
    	$output.= '<a href="'.site_url().'/wp-admin/">admin</a>'; 
         }
          return $output; 
      } add_shortcode("login_form", "mqw_login_form"); 

      //ejemplo de shortcode
     function shortcode_gracias() {
	return '<p>¡Gracias por leer mi blog!, si te gustó suscríbete al feed RSS</p>';
}
add_shortcode('gracias', 'shortcode_gracias');



// redireccionar si no eres admin

add_filter('login_redirect', 'dashboard_redirect');
function dashboard_redirect($url) {
global $current_user;
get_currentuserinfo();
$level = (int) $current_user->wp_user_level;
if ( $level < 10 && $level > 3 ) {
$url = 'wp-admin/post-new.php';
}
return $url;
}