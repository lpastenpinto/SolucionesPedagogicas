<?php
/*
Template Name: Planificacion anual 2
*/
?>


<?php get_header(); ?>
<h1 >Planificacion de trayecto anual</h1><br><br>
<form id="wp_login_form" action="http://localhost/blog/?page_id=127" method="post">

<label><strong>Unidad 1</strong></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Nº de semanas</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="semana1" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Entre</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="e1" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>AI</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="ha1" size="10" class="text" value=""><br><br>

<label><strong>Unidad 2</strong></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Nº de semanas</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="semana1" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Entre</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="e2" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>AI</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="ha2" size="10" class="text" value=""><br><br>

<label><strong>Unidad 3</strong></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Nº de semanas</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="semana1" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Entre</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="e3" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>AI</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="ha3" size="10" class="text" value=""><br><br>

<label><strong>Unidad 4</strong></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Nº de semanas</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="semana1" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Entre</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="e4" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>AI</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="ha4" size="10" class="text" value=""><br><br>









 <br><br>

</form>
<br><br>
<a href="http://localhost/blog/?page_id=189">Volver atras</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=127">Volver al menu</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="wp-content/themes/child_twentyfourteen/mensaje2.php">Guardar</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=195">Siguiente</a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php get_sidebar(); ?>
<?php get_footer(); ?>