<?php
/*
Template Name: Planificacion unidad 3
*/
?>
<?php get_header(); ?>
<table style="border:1px solid #000000;" frame="void"cellspacing="5" cellpadding="5" border="5" bordercolor="#000000;" >
<tr>
    <td id="b" style="border:1px solid #000000;"><h2 id="linea">Trayecto</h2>   sem |clase</td>
    <td id="b" style="border:1px solid #000000;">Conceptos a aprender</td>
    <td id="b" style="border:1px solid #000000;">Obj. de  Aprendizaje</td>
    <td id="b" style="border:1px solid #000000;">Indicadores de evaluación</td>
    <td id="b" style="border:1px solid #000000;">Habilidades</td>
    <td id="b" style="border:1px solid #000000;">Actitudes</td>
    <td id="b" style="border:1px solid #000000;">Estrategia de Aprendizaje</td>
    <td id="b" style="border:1px solid #000000;">Formas de evaluación</td>
    <td id="b" style="border:1px solid #000000;">Tipos de evaluación</td>
</tr>  
<tr>
    <td id="b" style="border:1px solid #000000;">&nbsp;</td>
    <td id="b" style="border:1px solid #000000;">&nbsp;</td>
    <td id="b" style="border:1px solid #000000;">&nbsp;</td>
    <td id="b" style="border:1px solid #000000;">&nbsp;</td>
    <td id="b" style="border:1px solid #000000;">&nbsp;</td>
    <td id="b" style="border:1px solid #000000;">&nbsp;</td>
    <td id="b" style="border:1px solid #000000;">&nbsp;</td>
    <td id="b" style="border:1px solid #000000;">&nbsp;</td>
    <td id="b" style="border:1px solid #000000;">&nbsp;</td>
</tr>  

</table><br><br><br><br><br><br><br><br>
<a href="http://localhost/blog/?page_id=199">Volver atras</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=127">Volver al menu</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="wp-content/themes/child_twentyfourteen/mensaje7.php">Guardar</a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php get_sidebar(); ?>
<?php get_footer(); ?>