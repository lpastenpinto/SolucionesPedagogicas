<?php
/*
Template Name: Planificacion diaria 2
*/
?>
<?php get_header(); ?>
<h1 >Planificacion Clase a Clase</h1><br><br><br>
<form id="wp_login_form" action="" method="post">
<label>Conceptos Clave</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<label>Indicadores :</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<label>Objetivos de Aprendizaje/Aprendizaje esperado:</label><br><br>
<SELECT NAME="concepto" size="1">
   <OPTION VALUE="co1">concepto 1</OPTION>
   <OPTION VALUE="co2">concepto 2</OPTION>
   <OPTION VALUE="co3">concepto 3</OPTION>
   <OPTION VALUE="co4">concepto 4</OPTION>
   
   
</SELECT>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<SELECT NAME="indicadores" size="1">
   <OPTION VALUE="in1">Formulan preguntas sobre ...</OPTION>
   <OPTION VALUE="in2">Observan e ilustran... </OPTION>
   <OPTION VALUE="in3">Identifican características...</OPTION>
   <OPTION VALUE="in4">Comparan las características... </OPTION>
   
</SELECT>

&nbsp;&nbsp;&nbsp;&nbsp;
<SELECT NAME="objetivos" size="1">
   <OPTION VALUE="un1">Describir, dar ejemplos y practicar hábitos de vida saludable </OPTION>
   <OPTION VALUE="un2">Identificar y describir la ubicación y la función de los sentidos </OPTION>
   <OPTION VALUE="un3">Reconocer y observar, por medio de la exploración, que los seres vivos crecen</OPTION>
   <OPTION VALUE="un4">Observar y comparar animales de acuerdo a características </OPTION>
   
</SELECT>
 <br><br>

</form>
<br><br><br><br><br><br><br><br>
<a href="http://localhost/blog/?page_id=203">Volver</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=127">Volver al menu</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="wp-content/themes/child_twentyfourteen/mensaje6.php">Guardar</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=207">Siguiente</a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php get_sidebar(); ?>
<?php get_footer(); ?>