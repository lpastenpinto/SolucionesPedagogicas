<?php
/*
Template Name: Planificacion Unidad 2
*/
?>
<?php get_header(); ?>
<h1 >Planificacion de Unidad</h1><br><br>
<form id="wp_login_form" action="http://localhost/blog/?page_id=127" method="post">

<label><strong>Unidad :</strong></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<SELECT NAME="unidad" size="1">
   <OPTION VALUE="u1">1</OPTION>
   <OPTION VALUE="u2">2</OPTION>
   <OPTION VALUE="u3">3</OPTION>
   <OPTION VALUE="u4">4</OPTION>
   
   
</SELECT> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Nº de semanas</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="semana1" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Entre</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="e1" size="10" class="text" value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>AI</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="h1" size="10" class="text" value=""><br><br>
<br><br><h1 >SEMESTRE</h1><br><br>
<label><strong>Mes :</strong></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<SELECT NAME="mes" size="1">
   <OPTION VALUE="m1">Enero </OPTION>
   <OPTION VALUE="m2">Febrero</OPTION>
   <OPTION VALUE="m3">Marzo</OPTION>
   <OPTION VALUE="m4">Abril</OPTION>
    <OPTION VALUE="m5">Mayo</OPTION>
   <OPTION VALUE="m6">Junio</OPTION>
   <OPTION VALUE="m7">Julio</OPTION>
   <OPTION VALUE="m8">Agosto</OPTION>
    <OPTION VALUE="m9">Septiembre</OPTION>
   <OPTION VALUE="m10">Octubre</OPTION>
   <OPTION VALUE="m11">Noviembre</OPTION>
   <OPTION VALUE="m12">Diciembre</OPTION>
</SELECT>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><strong>Nombre de la Unidad:</strong></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="nombre_unidad" size="40" class="text" value="">

 <br><br> <br><br>

</form>
<br><br>
<a href="http://localhost/blog/?page_id=197">Volver atras</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=127">Volver al menu</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="wp-content/themes/child_twentyfourteen/mensaje4.php">Guardar</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=201">Siguiente</a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php get_sidebar(); ?>
<?php get_footer(); ?>