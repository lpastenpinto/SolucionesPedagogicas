<?php
/*
Template Name: mensaje4
*/
?>
<?php echo "<script>" ?>
<?php echo "alert('Sus datos han sido guardados exitosamente.');" ?>
<?php echo "window.location='http://localhost/blog/?page_id=199'" ?>
<?php echo "</script>" ?>
