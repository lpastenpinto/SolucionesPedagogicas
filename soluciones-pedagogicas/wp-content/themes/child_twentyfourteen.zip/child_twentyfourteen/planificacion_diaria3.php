<?php
/*
Template Name: Planificacion diaria 3
*/
?>
<?php get_header(); ?>
<table style="border:1px solid #000000;" frame="void"cellspacing="5" cellpadding="5" border="5" bordercolor="#000000;" >
<tr>
    <td id="i" style="border:1px solid #000000;">Nº de Clase</td>
    <td id="i" style="border:1px solid #000000;">Habilidad</td>
    <td id="i"style="border:1px solid #000000;">Narracion breve de la actividad</td>
    <td id="i"style="border:1px solid #000000;">Recursos  pedagogicos</td>
    
</tr>  
<tr>
    <td id="d"style="border:1px solid #000000;">&nbsp;</td>
    <td id="d"style="border:1px solid #000000;">&nbsp;</td>
    <td id="d"style="border:1px solid #000000;">&nbsp;</td>
    <td id="d"style="border:1px solid #000000;">&nbsp;</td>
   
</tr>  

</table><br><br><br><br><br><br><br><br>
<a href="http://localhost/blog/?page_id=199">Volver atras</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=127">Volver al menu</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="wp-content/themes/child_twentyfourteen/mensaje9.php">Guardar</a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php get_sidebar(); ?>
<?php get_footer(); ?>