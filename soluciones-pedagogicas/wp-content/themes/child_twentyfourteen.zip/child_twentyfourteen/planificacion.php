<?php
/*
Template Name: Planificacion
*/
?>
<?php get_header(); ?>
<div id="errors"><?php echo $errors;?></div>
<form id="wp_login_form1" action="http://localhost/blog/?page_id=189" method="post">
<input type="submit" id="submitbtn1" name="submitbtn1" value="Planificacion anual">
</form>
<form id="wp_login_form2" action="http://localhost/blog/?page_id=197" method="post">
<input type="submit" id="submitbtn2" name="submitbtn2" value="Planificacion unidad">
</form>
<form id="wp_login_form3" action="http://localhost/blog/?page_id=203" method="post">
<input type="submit" id="submitbtn3" name="submitbtn3" value="Planificacion diaria">
</form>
<?php get_sidebar(); ?>
<?php get_footer(); ?>