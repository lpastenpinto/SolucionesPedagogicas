<?php
/*
Template Name: Planificacion diaria
*/
?>
<?php get_header(); ?>
<h1 >Planificacion Clase a Clase</h1><br><br><br>
<form id="wp_login_form" action="" method="post">
<label>Docente:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<SELECT NAME="Docentes" size="1">
   <OPTION VALUE="d1">Profesor 1</OPTION>
   <OPTION VALUE="d2">Profesor 2</OPTION>
   <OPTION VALUE="d3">Profesor 3</OPTION>
   <OPTION VALUE="d4">Profesor 4</OPTION>
   
   
</SELECT> 

&nbsp;&nbsp;&nbsp;&nbsp;<label>Curso :</label>
<SELECT NAME="Curso" size="1">
   <OPTION VALUE="8">8º Basico</OPTION>
   <OPTION VALUE="7">7º Basico</OPTION>
   <OPTION VALUE="6">6º Basico</OPTION>
   <OPTION VALUE="5">5º Basico</OPTION>
   <OPTION VALUE="4">4º Basico</OPTION>
   <OPTION VALUE="3">3º Basico</OPTION>
   <OPTION VALUE="2">2º Basico</OPTION>
   <OPTION VALUE="1">1º Basico</OPTION> 
</SELECT>

&nbsp;&nbsp;&nbsp;&nbsp;<label>Unidad de aprendizaje :</label>
<SELECT NAME="Curso" size="1">
   <OPTION VALUE="un1">Unidad 1</OPTION>
   <OPTION VALUE="un2">Unidad 2</OPTION>
   <OPTION VALUE="un3">Unidad 3</OPTION>
   <OPTION VALUE="un4">Unidad 4</OPTION>
   
</SELECT>
 <br><br>

<label>Asignatura :</label>
<SELECT NAME="Asignatura" size="1">
   <OPTION VALUE="matematicas">Matematicas</OPTION>
   <OPTION VALUE="lenguaje">Lenguaje y comunicación</OPTION>
   <OPTION VALUE="cienciasn">Ciencias Naturales</OPTION>
   <OPTION VALUE="historia">Historia</OPTION>
   <OPTION VALUE="gcienciass">Geografia y Ciencias sociales</OPTION>
   <OPTION VALUE="artes">Artes visuales</OPTION>
   
</SELECT> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<style>

</style>
<label>Numero de semana  :</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="nombre_semana" size="10" class="text" value=""><br><br>
<label>Actitudes :</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<SELECT NAME="actitudes" size="1" >
   <OPTION VALUE="act1">Demostrar curiosidad e interés por conocer seres vivos, objetos y/o eventos que conforman elentorno natural</OPTION>
   <OPTION VALUE="act2">Manifestar compromiso con un estilo de vida saludable a través del desarrollo físico y el autocuidado</OPTION>
   <OPTION VALUE="act3">Manifestar un estilo de trabajo y estudio riguroso y perseverante para lograr los aprendizajes de la
Asignatura.
</OPTION>
   <OPTION VALUE="act4">Explorar y observar la naturaleza, usando los sentidos apropiadamente durante investigaciones
experimentales guiadas. (OA a)
</OPTION>
   
   
</SELECT><br><br> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<SELECT NAME="actitudes2" size="1">
   <OPTION VALUE="act1">Demostrar curiosidad e interés por conocer seres vivos, objetos y/o eventos que conforman elentorno natural</OPTION>
   <OPTION VALUE="act2">Manifestar compromiso con un estilo de vida saludable a través del desarrollo físico y el autocuidado</OPTION>
   <OPTION VALUE="act3">Manifestar un estilo de trabajo y estudio riguroso y perseverante para lograr los aprendizajes de la
Asignatura.
</OPTION>
   <OPTION VALUE="act4">Explorar y observar la naturaleza, usando los sentidos apropiadamente durante investigaciones
experimentales guiadas. (OA a)
</OPTION>
   
   
</SELECT> 
</form>
<br><br><br><br><br><br><br><br>
<a href="http://localhost/blog/?page_id=127">Volver al menu</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="wp-content/themes/child_twentyfourteen/mensaje5.php">Guardar</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=205">Siguiente</a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php get_sidebar(); ?>
<?php get_footer(); ?>