<?php
/*
Template Name: Planificacion Unidad
*/
?>

<?php get_header(); ?>
<h1 >Planificacion de Unidad</h1><br><br>
<form id="wp_login_form" action="http://localhost/blog/?page_id=127" method="post">
<label>Docente:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="Docente" size="70" class="text" value=""><br><br>
<label>Asignatura :</label>
<SELECT NAME="Asignatura" size="1">
   <OPTION VALUE="matematicas">Matematicas</OPTION>
   <OPTION VALUE="lenguaje">Lenguaje y comunicación</OPTION>
   <OPTION VALUE="cienciasn">Ciencias Naturales</OPTION>
   <OPTION VALUE="historia">Historia</OPTION>
   <OPTION VALUE="gcienciass">Geografia y Ciencias sociales</OPTION>
   <OPTION VALUE="artes">Artes visuales</OPTION>
   
</SELECT> 

&nbsp;&nbsp;&nbsp;&nbsp;<label>Curso :</label>
<SELECT NAME="Curso" size="1">
   <OPTION VALUE="8">8º Basico</OPTION>
   <OPTION VALUE="7">7º Basico</OPTION>
   <OPTION VALUE="6">6º Basico</OPTION>
   <OPTION VALUE="5">5º Basico</OPTION>
   <OPTION VALUE="4">4º Basico</OPTION>
   <OPTION VALUE="3">3º Basico</OPTION>
   <OPTION VALUE="2">2º Basico</OPTION>
   <OPTION VALUE="1">1º Basico</OPTION> 
</SELECT>

&nbsp;&nbsp;&nbsp;&nbsp;<label>Año :</label>
<SELECT NAME="Curso" size="1">
   <OPTION VALUE="14">2014</OPTION>
   <OPTION VALUE="13">2013</OPTION>
   <OPTION VALUE="12">2012</OPTION>
   <OPTION VALUE="11">2011</OPTION>
   <OPTION VALUE="10">2010</OPTION>
   <OPTION VALUE="09">2009</OPTION>
   <OPTION VALUE="08">2008</OPTION>
   <OPTION VALUE="07">2007</OPTION> 
</SELECT>
 <br><br>

</form>
<br><br>
<a href="http://localhost/blog/?page_id=127">Volver al menu</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="wp-content/themes/child_twentyfourteen/mensaje3.php">Guardar</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/blog/?page_id=199">Siguiente</a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php get_sidebar(); ?>
<?php get_footer(); ?>