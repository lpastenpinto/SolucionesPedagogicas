
<div id="errors"><?php echo $errors;?></div>
<form id="wp_login_form" action="" method="post">
<?php
/*
Template Name: Registro Docente
*/
?>
<?php get_header(); ?>
<form id="wp_login_form" action="http://localhost/blog/?page_id=127" method="post">
<label>Usuario</label><br>
<input type="text" name="username" class="text" value=""><br>
<label>Contraseña</label><br>
<input type="password" name="password" class="text" value=""> <br>
<label>
<input name="rememberme" type="checkbox" value="forever">Remember me</label>

<input type="submit" id="btn" name="btn" value="Login">
</form>
<?php get_sidebar(); ?>
<?php get_footer(); ?>