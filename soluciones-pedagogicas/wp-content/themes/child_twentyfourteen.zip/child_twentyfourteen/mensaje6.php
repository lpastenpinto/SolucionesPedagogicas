<?php
/*
Template Name: mensaje6
*/
?>
<?php echo "<script>" ?>
<?php echo "alert('Sus datos han sido guardados exitosamente.');" ?>
<?php echo "window.location='http://localhost/blog/?page_id=205'" ?>
<?php echo "</script>" ?>
